import os


try:
    if os.path.isdir("photo"):
        pass
    else:
        os.makedirs("photo")
except:
    os.makedirs("photo")