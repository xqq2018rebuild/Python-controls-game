import os,shutil
# self_name=".mmm5"
# rename='.mp4'
self_name=".mp4"
rename='.mmm5'
def mymovefile(srcfile,dstfile):
    if not os.path.isfile(srcfile):
        print ("%s not exist!"%(srcfile))
    else:
        fpath,fname=os.path.split(dstfile)    #分离文件名和路径
        if not os.path.exists(fpath):
            os.makedirs(fpath)                #创建路径
        shutil.move(srcfile,dstfile)          #移动文件
        # print ("move %s -> %s"%( srcfile,dstfile))
def find_files(path):
    """
    """
    all_files=[]
    find_file=[]
    for file in os.listdir(path):
        this_file=os.path.join(path,file)
        if os.path.isfile(this_file):
            all_files.append(this_file)
            if os.path.splitext(this_file)[1]==self_name:
                this_file_new_name=os.path.splitext(this_file)[0]+rename
                os.renames(this_file,this_file_new_name)
                mymovefile(this_file_new_name, "D:\\ubuntu files\\xx2\\zc\\"+rename+"\\"+ os.path.split(this_file_new_name)[1])
                # find_file.append(os.path.splitext(this_file)[0]+'.mp4')
            # print(this_file)
        elif os.path.isdir(this_file):
            find_files(this_file)
            # print(this_file)
    return all_files,find_file
if __name__ == "__main__":
    all,other=find_files('D:\\ubuntu files\\xx2\\zc')
