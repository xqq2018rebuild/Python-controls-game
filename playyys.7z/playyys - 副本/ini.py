#-*- coding:utf-8 -*-
import op
from log import log


PHOTOPATH="photo/"
##########################################
#魂十
tiaozhan = op.PartOfTheScreen("挑战图片", PHOTOPATH + "tiaozhan.bmp", 20)
gouliang=op.PartOfTheScreen("狗粮满级图片", PHOTOPATH + "gouliang.bmp", 10)



#############################################
#公共
shengli1 = op.PartOfTheScreen("胜利图片1", PHOTOPATH + "shengli1.bmp", 30)
shengli2 = op.PartOfTheScreen("胜利图片2", PHOTOPATH + "shengli2.bmp", 50)
shibai=op.PartOfTheScreen("失败图片", PHOTOPATH + "shibai.bmp", 50)
xiaoguai=op.PartOfTheScreen("小怪", PHOTOPATH + "xiaoguai.bmp", 10)

zhubei=op.PartOfTheScreen("准备", PHOTOPATH + "zhunbei.bmp", 10)


#########################################
#剧情
juqing_rukou=op.PartOfTheScreen("剧情入口", PHOTOPATH + "剧情入口2.bmp", 10)
juqing_rukou=op.PartOfTheScreen("剧情入口", PHOTOPATH + "juqingrukou.bmp", 10)
juqing_skip=op.PartOfTheScreen("跳过", PHOTOPATH + "tiaoguo.bmp", 10)
juqing_skip2=op.PartOfTheScreen("快进", PHOTOPATH + "kuaijin.bmp", 10)
######################################
#探索
zhang28=op.PartOfTheScreen("二十八章", PHOTOPATH + "zhang28.bmp", 20)
tansuo=op.PartOfTheScreen("探索", PHOTOPATH + "tansuo.bmp", 20)
boss=op.PartOfTheScreen("boss", PHOTOPATH + "boss.bmp", 10)
zhiren=op.PartOfTheScreen("小纸人", PHOTOPATH + "zhiren.bmp", 10)
jiangli=op.PartOfTheScreen("奖励", PHOTOPATH + "jiangli.bmp", 10)

jujue=op.PartOfTheScreen("协作拒绝", PHOTOPATH + "jujue.bmp", 10)
jieshou=op.PartOfTheScreen("协作接受", PHOTOPATH + "jieshou.bmp", 10)











log.info("图片初始化完成")

