#-*- coding:utf-8 -*-



from ini import *
import time


def huan_gouliang():
    log.info("开始换狗粮")
    MAX_levl=''
    while True:
        huan_over= yield MAX_levl
        if not huan_over:
            return
        #换狗粮操作
        print("开始换狗粮")
        # time.sleep(5)
        MAX_levl='ok!'

def hunshi(n,c):
    log.info("开始挑战魂十")
    # t1=threading.Thread(target=tiaozhan.tap,name=tiaozhan,kwargs={'condition':1})
    c.send(None)
    while n>=1:
        shibai.tap(1)
        tiaozhan.tap(1)
        shengli1.tap(1)
        if shengli2.tap(1):n=n-1

        if gouliang.get_centerxy(1):
            huan_over=c.send(1)
            print("换狗粮%s"%huan_over)
        time.sleep(2)


def juqing():
    log.info("开始剧情")
    while True:
        shibai.tap(1)
        shengli1.tap(1)
        shengli2.tap(1)
        juqing_rukou.tap(1)
        juqing_skip.tap(1)
        juqing_skip2.tap(1)
        xiaoguai.tap(1)
        zhubei.tap(1)
        time.sleep(2)
def fuben(n):
    log.info("开始探索副本")
    while n>=0:
        if tansuo.tap(1):
            n-=1
            time.sleep(2)
        zhang28.tap(1)
        shibai.tap(1)
        shengli1.tap(1)
        shengli2.tap(1)
        xiaoguai.tap(1)
        zhubei.tap(1)
        boss.tap(1
		zhiren.tap(1)
		jiangli.tap(1)
		jujue.tap(1)
        time.sleep(2)
if __name__ == "__main__":
    # hunshi(1000,huan_gouliang())
    fuben(100)

    # logging.info("挑战魂十结束")