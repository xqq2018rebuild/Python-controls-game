import win32com.client
# import cv2
# import numpy as np
# from matplotlib import pyplot as plt
# import os
import time
import random


dm = win32com.client.Dispatch('dm.dmsoft')
locatime=time.asctime( time.localtime(time.time()) )
def tap(x,y):
    time1=random.randint(1, 10)
    # print(x,y)
    dm.MoveTo(x, y)
    dm.LeftClick()
    time.sleep(0.05*time1)
def xuanji():
    # dm.WheelDown() //滚轮下
    # chongbo=dm.FindPic(0, 0, 2000, 2000, "aaa/replay.bmp", "000000",0.9, 0)
    # if chongbo[0] != -1:
    zuobiao = dm.FindPic(0, 0, 2000, 2000, "aaa/xuanji.bmp|aaa/xuanji2.bmp|aaa/now.bmp", "000000",0.9, 0)
    if zuobiao[0] == 0 and [1] != -1 and zuobiao[2] != -1:
        tap(zuobiao[1], zuobiao[2]+30)
        print(time.asctime( time.localtime(time.time()) ),":正在选集")
        dm.MoveTo(zuobiao[1]-200, zuobiao[2]+30)
        time.sleep(3)
        dm.WheelDown()
        dm.WheelDown()
        dm.WheelDown()
    if zuobiao[0] == 1 and [1] != -1 and zuobiao[2] != -1:
        tap(zuobiao[1], zuobiao[2]+60)
        print(time.asctime(time.localtime(time.time())), ":正在选集")
        dm.MoveTo(zuobiao[1]-200, zuobiao[2]+30)
        time.sleep(2)

    if zuobiao[0] == 2 and [1] != -1 and zuobiao[2] != -1:
        if zuobiao[2]>=950 :
            dm.MoveTo(zuobiao[1]+100, zuobiao[2])
            time.sleep(2)
            dm.WheelDown()
            dm.WheelDown()
            dm.WheelDown()
            dm.WheelDown()
            dm.WheelDown()
            print(time.asctime(time.localtime(time.time())), ":正在下滑播放列表")

        time.sleep(2)

def see_to_tap(bmp):
    zuobiao = dm.FindPic(0, 0, 2000, 2000,bmp, "000000", 0.8, 0)
    if zuobiao[0] == 0 and [1] != -1 and zuobiao[2] != -1:
        tap(zuobiao[1], zuobiao[2])
        return 1

def play2():
    zuobiao = dm.FindPic(0, 0, 2000, 2000,"aaa/play.bmp","000000", 0.9, 0)
    if zuobiao[0] == 0 and zuobiao[1] != -1 and zuobiao[2] != -1:
        tap(zuobiao[1],zuobiao[2])
        print(time.asctime(time.localtime(time.time())), ":正在播放")
        dm.MoveTo(zuobiao[1]+50,zuobiao[2]-50)
def playx2():
    zuobiao = dm.FindPic(0, 0, 2000, 2000, "aaa/su.bmp", "000000", 0.9, 0)
    if zuobiao[0] == 0 and zuobiao[1] != -1 and zuobiao[2] != -1:
        dm.MoveTo(zuobiao[1]+8, zuobiao[2]+8)
        time.sleep(2)
        tap(zuobiao[1], zuobiao[2]-20)
        dm.MoveTo(zuobiao[1] + 10, zuobiao[2] - 50)
def xuanzeA():
    # zuobiao = dm.FindPic(0, 0, 2000, 2000, "aaa/A.bmp", "000000", 0.9, 0)
    if see_to_tap("aaa/A.bmp|aaa/AA.bmp"):
        print(time.asctime(time.localtime(time.time())), ":正在选A")
    see_to_tap("aaa/tijiao.bmp")
    see_to_tap("aaa/jixu.bmp")

def xuanzeB():
    # zuobiao = dm.FindPic(0, 0, 2000, 2000, "aaa/A.bmp", "000000", 0.9, 0)
    if see_to_tap("aaa/B.bmp|aaa/BB.bmp"):
        print(time.asctime(time.localtime(time.time())), ":正在选B")
    see_to_tap("aaa/tijiao.bmp")
    see_to_tap("aaa/jixu.bmp")
def main():
    # playx2()
    # xuanji()
    # see_to_tap("aaa/play.bmp")
    # dm.WheelDown()
    # see_to_tap ("aaa/xuanji2.bmp")

    while True:

        if see_to_tap("aaa/shipin.bmp"):
            time.sleep(3)
            dm.WheelDown()
            dm.WheelDown()
            dm.WheelDown()
        xuanji()
        xuanzeA()
        xuanzeB()
        play2()
        # playx2()

        time.sleep(3)
if __name__ == '__main__':
    main()


# def play():
#         zuobiao= dm.FindPic(0, 0, 2000, 2000,"aaa/quanping.bmp|aaa/bofang.bmp|aaa/bofang2.bmp|aaa/bofang3.bmp|aaa/bofang4.bmp|aaa/bofang5.bmp|aaa/bofang6.bmp", "000000", 0.9, 0)
#         # if zuobiao[0]==0 and [1] != -1 and zuobiao[2] != -1:
#         #     tap(zuobiao[1],zuobiao[2]) #全屏
#         if zuobiao[0]==1 and zuobiao[1] != -1 and zuobiao[2] != -1:
#             tap(zuobiao[1],zuobiao[2]) #非全屏播放
#         elif zuobiao[0]==2 and zuobiao[1] != -1 and zuobiao[2] != -1:
#             tap(zuobiao[1],zuobiao[2]) #全屏播放
#         elif zuobiao[0]==3 and zuobiao[1] != -1 and zuobiao[2] != -1:
#             tap(zuobiao[1],zuobiao[2]) #全屏播放
#         elif zuobiao[0]==4 and zuobiao[1] != -1 and zuobiao[2] != -1:
#             tap(zuobiao[1],zuobiao[2]) #全屏播放
#         elif zuobiao[0]==5 and zuobiao[1] != -1 and zuobiao[2] != -1:
#             tap(zuobiao[1],zuobiao[2]) #全屏播放
#         elif zuobiao[0]==6 and zuobiao[1] != -1 and zuobiao[2] != -1:
#             tap(zuobiao[1],zuobiao[2]) #全屏播放
#         # print(zuobiao)
#         # if bofang_xy[1] != -1 and bofang_xy[2] != -1:
#         #     tap(bofang_xy[1],bofang_xy[2])
